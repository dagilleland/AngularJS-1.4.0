require('./dist/router.es5');
module.exports = 'ngNewRouter';
