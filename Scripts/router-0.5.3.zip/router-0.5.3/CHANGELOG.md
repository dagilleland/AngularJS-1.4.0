<a name"v0.5.3"></a>
### v0.5.3 magnificent-fortitude (2015-03-30)

#### Bug Fixes

* **build:** add missing files from dist ([10e7174c](https://github.com/angular/router/commit/10e7174c)) (oops!!)


<a name"v0.5.2"></a>
### v0.5.2 extraterrestrial-illusion (2015-03-30)


#### Features

* Include minified files in build


#### Bug Fixes

* Inject `$scope` into activate hook ([2136ca8a](https://github.com/angular/router/commit/2136ca8a), closes [#192](https://github.com/angular/router/issues/192))
* **wizard example:** fix annotation and link ([e9a6e26c](https://github.com/angular/router/commit/e9a6e26c))
* Handle anchor elts with no href ([dbdd5f39](https://github.com/angular/router/commit/dbdd5f39), closes [#206](https://github.com/angular/router/issues/206))
