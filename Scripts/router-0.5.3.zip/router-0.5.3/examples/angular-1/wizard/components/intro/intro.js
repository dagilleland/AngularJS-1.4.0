angular.module('myApp.intro', []).
  controller('IntroController', [IntroController]);

function IntroController () {}
