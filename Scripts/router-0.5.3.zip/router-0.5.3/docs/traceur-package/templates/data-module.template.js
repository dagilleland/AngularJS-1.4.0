angular.module('{$ doc.moduleName $}', [])

.value('{$ doc.serviceName $}', {$ doc.value | json $});